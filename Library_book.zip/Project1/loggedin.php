<?php # Script 12.9 - loggedin.php #2
// The user is redirected here from login.php.

session_start(); // Start the session.

// If no session value is present, redirect the user:
if (!isset($_SESSION['user_id'])) {

	// Need the functions:
	require ('includes/login_functions.inc.php');
	redirect_user();	

}

// Set the page title and include the HTML header:
$page_title = 'Logged In!';
include ('includes/header.html');

// Print a customized message:
echo "<h1>Logged In!</h1>
<p>You are now logged in, {$_SESSION['first_name']}!</p>
<br/><br/>
<h2>About Us</h2>
<p>MyBookie is a book database where user can look for the book they wanted.</p><br/>
<p>MyBookie also allow user to upload book they like for other users to view.</p><br/>
<p>In this database user allow to edit delete the book that no longer needed.</p><br/>

<p><a href=\"logout.php\">Logout</a></p>";

include ('includes/footer.html');
?>