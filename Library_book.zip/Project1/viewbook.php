<?php 

session_start(); // Access the existing session.
if (!isset($_SESSION['user_id'])) {
	require('includes/login_functions.inc.php');
        redirect_user();
}

// This script retrieves all the records from the users table.
// This new version links to edit and delete pages.


$page_title = 'View the Current Users';
include ('includes/header.html');
echo '<h1>Book Library</h1>';

require ('../mysqli_connect.php');
		
// Define the query:

$q = "SELECT title, author, category, bookinfo, image , DATE_FORMAT(registration_date, '%d %M %Y') AS dr,title,author, category, bookinfo,image, user_id FROM books ORDER BY registration_date ASC";		
$r = @mysqli_query ($dbc, $q);

// Count the number of returned rows:
$num = mysqli_num_rows($r);

if ($num > 0) { // If it ran OK, display the records.

	// Print how many users there are:
	echo "<p>There are currently $num inserted books.</p>\n";

	// Table header:
	echo '<table align="center" cellspacing="5" cellpadding="3" width="100%">
	<tr>
		<td align="center"><b>Edit</b></td>
		<td align="center"><b>Delete</b></td>
		<td align="center"><b>Title</b></td>
		<td align="center"><b>Author</b></td>
		<td align="center"><b>Category</b></td>
		<td align="center"><b>Book Information</b></td>
		<td align="center"><b>Book Cover</b></td>
		<td align="center"><b>Date</b></td>
		
	</tr>
';
	
	// Fetch and print all the records:
	while ($row = mysqli_fetch_array($r, MYSQLI_ASSOC)) {
		echo '<tr>
			<td align="center"><a href="editbook.php?id=' . $row['user_id'] . '">Edit</a></td>
			<td align="center"><a href="deletebook.php?id=' . $row['user_id'] . '">Delete</a></td>
			<td align="center">' . $row['title'] . '</td>
			<td align="center">' . $row['author'] . '</td>
			<td align="center">' . $row['category'] . '</td>
			<td align="center">' . $row['bookinfo'] . '</td>
			<td align="left"> <img src="uploads/'.($row['image']).'" height="160" width="100"   /> </td>
			<td align="center">' . $row['dr'] . '</td>
		</tr>
		';
	}

	echo '</table>';
	mysqli_free_result ($r);	

} else { // If no records were returned.
	echo '<p class="error">There are currently no book inserted.</p>';
}

mysqli_close($dbc);

include ('includes/footer.html');
?>