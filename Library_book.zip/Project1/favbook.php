<?php 
// This page is for editing a user record.
// This page is accessed through view_users.php.
session_start(); // Access the existing session.
if (!isset($_SESSION['user_id'])) {
    require('includes/login_functions.inc.php');
        redirect_user();
}
$page_title = 'Top 10 Best Book ';
include ('includes/header.html');
?>
<!DOCTYPE html>

<html>
	<meta charset = "UTF-8">
	<title>Top 10 Best Book</title>
	<style>
	</style>
	<head>
	<meta name ="viewport" content ="width=device-width, initial-scale="1">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>
	<style>
	body{
		background: #FFCC99;	
	}
	.container{
		margin-top: 50px;
	}
	.glyphicon-search{
		padding:25px;
		font-size:20px;
	}
	.btn-default{
		background:orange;
		width: 50px;
		padding:25px
	}
	.form-control{
		padding:25px;
		font-size:20px;
	}
	</style>
	</head>
	<body>
	<h1><center><br/><br/>Top 10 Best Book</center></h1>
	<div class ="container">
		<form>
			<div class ="input-group">
				<input type = "text" class = "form-control" placeholder ="Search" name="search">
				<div class ="input-group-btn">
				<button class = "btn btn-default" type = "submit">
				<i class ="glyphicon glyphicon=search"></i></button>
				</div>
			</div>
				
		</form>
		<br/><br/><table class = "center">
			<thead>
				<tr>
					<td>
						<img src="one.jpg" WIDTH=200 HEIGHT=500>
					</td>
					<td>
						<img src="two.jpg" WIDTH=200 HEIGHT=500>
					</td>
					<td>
						<img src="three.jpg" WIDTH=200 HEIGHT=500>
					</td>
					<td>
						<img src="four.jpg" WIDTH=200 HEIGHT=500>
					</td>
					<td>
						<img src="five.jpg" WIDTH=200 HEIGHT=500>
					</td>
					<td>
						<img src="last.jpg" WIDTH=200 HEIGHT=500>
					</td>
				</tr>
				<tr>
					<td><h2>The Glass Hotel</h2>
					</td>
					<td><h2>My Dark Vanessa</h2>
					</td>
					<td><h2>Long Bright River<h2>
					</td>
					<td><h2>Uncanny Valley</h2>
					</td>
					<td><h2>Weather</h2>
					</td>
					<td><h2>Last Couple Standing</h2>
					</td>
				</tr>
				<tr>
					<td>
						<img src="six.jpg" WIDTH=200 HEIGHT=500>
					</td>
					<td>
						<img src="seven.jpg" WIDTH=200 HEIGHT=500>
					</td>
					<td>
						<img src="eight.jpg" WIDTH=200 HEIGHT=500>
					</td>
					<td>
						<img src="nine.jpg" WIDTH=200 HEIGHT=500>
					</td>
					<td>
						<img src="ten.jpg" WIDTH=200 HEIGHT=500>
					</td>
					<td>
						<img src="golden.jpg" WIDTH=200 HEIGHT=500>
					</td>
				</tr>
				<tr>
					<td><h2>Memorial</h2>
					</td>
					<td><h2>African American <br/>Poetry<h2>
					</td>
					<td><h2>The Historical <br/>Office of Corrections</h2>
					</td>
					<td><h2>Jack</h2>
					</td>
					<td><h2>The Cold Millions</h2>
					</td>
					<td><h2>Golden Gates</h2>
					</td>
				</tr>
				<tr>
					<td>
						<img src="eleven.jpg" WIDTH=200 HEIGHT=500>
					</td>
					<td>
						<img src="twelve.jpg" WIDTH=200 HEIGHT=500>
					</td>
						
					<td>
						<img src="forteen.jpg" WIDTH=200 HEIGHT=500>
					</td>
					<td>
						<img src="hollywood.jpg" WIDTH=200 HEIGHT=500>
					</td>
					<td>
						<img src="sansei.jpg" WIDTH=200 HEIGHT=500>
					</td>
					<td>
						<img src="in.jpg" WIDTH=200 HEIGHT=500>
					</td>
				</tr>
				<tr>
					<td><h2>Leave the World <br/>Behind</h2>
					</td>
					<td><h2>Red Pill<h2>
					</td>
					<td><h2>Boys of Alabama</h2>
					</td>
					<td><h2>Hollywood Park</h2>
					</td>
					<td><h2>Sansei and <br/>Sensibility</h2>
					</td>
					<td><h2>In the Land of Men</h2>
					</td>
			</thead>
		</table></center>
	</body>	
</html>

<?php
include ('includes/footer.html');
?>
