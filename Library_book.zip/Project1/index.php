<?php

session_start(); // Access the existing session.
if (!isset($_SESSION['user_id'])) {

    $_SESSION = array(); // Clear the variables.
    session_destroy(); // Destroy the session itself.
    setcookie ('PHPSESSID', '', time()-3600, '/', '', 0, 0); // Destroy the cookie.
}

$page_title = 'Welcome to Bookie';
include ('includes/header.html');

?>
<h1>BookShelf</h1>
<p>Here are the pages We've created</p>
<p>1.Add New Book</p>
<p>2.View Book Database</p>
<p>3.Favourite Books</p>
<p>**Please Login to Access All Pages</p>


<?php
include ('includes/footer.html');
?>
