<?php 
// This script performs an INSERT query to add a record to the users table.

session_start(); // Access the existing session.
if (!isset($_SESSION['user_id'])) {  
}

$page_title = 'Add New Book';
include ('includes/header.html');

	// Check for form submission:
	if ($_SERVER['REQUEST_METHOD'] == 'POST') {

	$errors = array(); // Initialize an error array.
	
	// Check for a title:
	if (empty($_POST['title'])) {
		$errors[] = 'You forgot to enter your book title.';
	} else {
		$t = trim($_POST['title']);
	}
	
	// Check for a author:
	if (empty($_POST['author'])) {
		$errors[] = 'You forgot to enter your the author.';
	} else {
		$a = trim($_POST['author']);
	}
	
	// Check for a category:
	if (empty($_POST['category'])) {
		$errors[] = 'You forgot to enter book category.';
	} else {
		$c = trim($_POST['category']);
	}
	
	// Check for a book information:
	if (empty($_POST['bookinfo'])) {
		$errors[] = 'You forgot to enter your book information.';
	} else {
		$b = trim($_POST['bookinfo']);
	}
	
	//check for image
    if (empty($_POST['image'])) {
        $errors[] = 'You forgot to upload the cover  of the book.';
    } else {

		$image= trim($_POST['image']);
	}
	
	
	
	
	if (empty($errors)) { // If everything's OK. ($fn && $ln && $pn && $e)
	
		// Register the user in the database...
		
		require ('../mysqli_connect.php'); // Connect to the db.

		// Make the query:
		$q = "INSERT INTO books (title, author,category,bookinfo,registration_date,image) VALUES ('$t', '$a', '$c', '$b', NOW(),'$image' )";		
		
		$r = mysqli_query ($dbc, $q); // Run the query.
		if ($r) { // If it ran OK.

			// Print a message:
			echo '<h1>Thank you!</h1>
		<p>The book has been entered into the database.</p>';	

		} else { // If it did not run OK.
	
			// Public message:
			echo '<h1>System Error</h1>
			<p class="error">The book could not be stored in database due to a system error. We apologize for any inconvenience.</p>'; 
	
			// Debugging message:
			echo '<p>' . mysqli_error($dbc) . '<br /><br />Query: ' . $q . '</p>';
				
		} // End of if ($r) IF.
		
		mysqli_close($dbc); // Close the database connection.
		
		// Include the footer and quit the script:
		include ('includes/footer.html'); 
		exit();
		
	} else { // Report the errors.
	
		echo '<h1>Error!</h1>
		<p class="error">The following error(s) occurred:<br />';
		foreach ($errors as $msg) { // Print each error.
			echo " - $msg<br />\n";
		}
		echo '</p><p>Please try again.</p><p><br /></p>';
		
	} // End of if (empty($errors)) IF.

} // End of the main Submit conditional.
?>
<h1>Add New Book</h1>
<form action="addnewbook.php" method="post" enctype="multipart/form.data"><br/><br/>

<fieldset><legend>Enter book information in the form below:</legend>

	<div class="form-group">
                <label>Title</label> 
                <input type="text" name="title" class="form-control"
                value="<?php if (isset($_POST['title'])) echo $_POST['title']; ?>">

    </div>
	
	<div class="form-group">
                <label>Author</label> 
                <input type="text" name="author" class="form-control"
                value="<?php if (isset($_POST['author'])) echo $_POST['author']; ?>">

    </div>
	
	<div class="form-group">
				<label>Category</label> 
                <?php 
				if (isset($_POST['category'])) echo $_POST['category'];
				$programme = array (1 => 'Fiction', 'Non-Fiction','Romance & Drama' ,'Narrative', 'Mystery', 'Religion', 'Historical', 'Horror', 'Thriller');
	
				echo '<select name="category">';
	
				foreach ($programme as $key => $value) {
				echo "<option value=\"$value\">$value</option>\n";
				}
	
				echo '</select>';
				?>

    </div>
	
	<div class="form-group">
                <label>Book Information</label> 
                <input type="text" name="bookinfo" class="form-control"
                value="<?php if (isset($_POST['bookinfo'])) echo $_POST['bookinfo']; ?>">

    </div>
	
	<div class="form-group">
                <label>Book Cover</label>
                <br/>
                <label for="image"><i>Upload your book cover image:</i></label>
                <input type="file" id="image" name="image" />
            </div>
	
	</div>
	
	</fieldset>
	
	<p align="center">
	<input type="submit" name="insert " id="insert" value="Add Book" class="btn btn-info" /></p>
	
</form>
<?php include ('includes/footer.html'); ?>